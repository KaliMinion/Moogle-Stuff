-- Helper Variables --
	local API = MoogleLib.API
	local Lua = MoogleLib.Lua
	local General = Lua.general
	local Debug = Lua.debug
	local IO = Lua.io
	local Math = Lua.math
	local OS = Lua.os
	local String = Lua.string
	local Table = Lua.table
	local Gui = MoogleLib.Gui

	local MinionPath = API.MinionPath
	local LuaPath = API.LuaPath
	local MooglePath = API.MooglePath
	local ImageFolder = API.ImageFolder
	local ScriptsFolder = API.ScriptsFolder
	local ACRFolder = API.ACRFolder
	local SenseProfiles = API.SenseProfiles
	local SenseTriggers = API.SenseTriggers
-- End Helper Variables --

-- API Variables --
	local Initialize = API.Initialize
	local Vars = API.Vars
	local CurrentTarget = API.CurrentTarget
-- End API Variables --

-- General Variables --
	local Error = General.Error
	local IsNil = General.IsNil
	local NotNil = General.NotNil
	local Is = General.Is
	local IsAll = General.IsAll
	local Not = General.Not
	local NotAll = General.NotAll
	local Type = General.Type
	local NotType = General.NotType
	local Size = General.Size
	local Empty = General.Empty
	local NotEmpty = General.NotEmpty
-- End General Variables --

-- Debug Variables --
	local d2 = Debug.d2
-- End Debug Variables --

-- Input and Output (IO) Variables --
-- End Input and Output (IO) Variables --

-- Math Variables --
	local Sign = Math.Sign
	local Round = Math.Round
-- End Math Variables --

-- Operating System (OS) Variables --
	local PowerShell = OS.PowerShell
	local CreateFolder = OS.CreateFolder
	local DeleteFile = OS.DeleteFile
	local CMD = OS.CMD
	local DownloadString = OS.DownloadString
	local DownloadTable = OS.DownloadTable
	local DownloadFile = OS.DownloadFile
	local VersionCheck = OS.VersionCheck
	local Ping = OS.Ping
-- End Operating System (OS) Variables --

-- String Variables --
	local Split = String.Split
-- End String Variables --

-- Table Variables --
	local Valid = Table.Valid
	local NotValid = Table.NotValid
	local InsertIfNil = Table.InsertIfNil
	local RemoveIfNil = Table.RemoveIfNil
	local UpdateIfChanged = Table.UpdateIfChanged
	local RemoveExpired = Table.RemoveExpired
	local Unpack = Table.Unpack
	local Print = Table.Print
-- End Table Variables --

-- GUI Variables --
	local WindowStyle = Gui.WindowStyle
	local WindowStyleClose = Gui.WindowStyleClose
	local ColorConv = Gui.ColorConv
	local SameLine = Gui.SameLine
	local Indent = Gui.Indent
	local Unindent = Gui.Unindent
	local Space = Gui.Space
	local Text = Gui.Text
	local Checkbox = Gui.Checkbox
	local Tooltip = Gui.Tooltip
	local GetRemaining = Gui.GetRemaining
	local HotKey = Gui.HotKey
-- End GUI Variables --